<?php
return [
    'Welcome' => 'សូមស្វាគមន៍',
    'Station Name' => 'ឈ្មោះស្ថានីយ',
    'Reference Station' => 'ស្ថានីយ​យោង',
    'Create' => 'បង្កើត',
    'Home' => 'ទំព័រដើម',
    'Station Management' => 'គ្រប់គ្រងស្ថានីយ',
    'Survey Station' => 'ស្ថានីយ​ស្ទង់មតិ',
    'English' => 'អង់គ្លេស',
    'Cambodian' => 'ខ្មែរ',
    'Logout' => 'ចាកចេញ',
    'Submit' => 'បញ្ជូន',
    'Save' => 'រក្សាទុក',
    'Upload image' => 'ផ្ទុករូបភាព',
    'Survey Site' => 'តំបន់ស្ទង់មតិ',
    'Choose' => 'ជ្រើសរើស'
];